package webservice.client.wmsmsk;

import java.io.IOException;
import java.io.StringReader;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.hibernate.Session;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import ru.defo.controllers.ArticleController;
import ru.defo.managers.PreOrderManager;
import ru.defo.managers.PreOrderPosManager;
import ru.defo.model.WmArticle;
import ru.defo.model.WmPreOrder;
import ru.defo.model.WmPreOrderPos;
import ru.defo.util.ErrorMessage;
import ru.defo.util.HibernateUtil;

public class WSReciveController {

	SAD_WMSObmenPortTypeProxy proxy;
	PreOrderManager preOrdMgr = new PreOrderManager();

	@SuppressWarnings("unused")
	public WSReciveController() {
		proxy = new SAD_WMSObmenPortTypeProxy();

		WmPreOrder preOrder;
		Document doc = null;

		List<WmPreOrderPos> preOrderPosList = new ArrayList<WmPreOrderPos>();

		ServiceMessageType[] typeArray = ServiceMessageType.getMessageTypesArray();
		for (ServiceMessageType messageType : typeArray) {
			System.out.println("\n\n\n...:::::: " + messageType.typeName());
			try {

				DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();

				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(getXML(messageType)));
				if(is != null)
				  doc = builder.parse(is);

				Node root = doc.getDocumentElement();
				NodeList nodes = root.getChildNodes();
				for (int i = 0; i <= nodes.getLength(); i++) {
					Node node = nodes.item(i);
					if (node != null && node.getNodeName() == messageType.typeName()) {
						////////////////////////
						System.out.println(node.getNodeName()+"--->" + node.getTextContent().intern()  );

						preOrder = new WmPreOrder(preOrdMgr.getNextPreOrderId());

						NodeList nodes0 = node.getChildNodes();
						for(int k = 0; k <= nodes0.getLength(); k++)
						{
							Node node0 = nodes0.item(k);
							if(node0 != null && node0.getNodeType() != Node.TEXT_NODE)
							{
								//createWmsDoc(node0, preOrder, preOrderPosList);
								System.out.println("node0 : "+node0.getTextContent());
							}
						}


						/*
						if(preOrder != null){
							PreOrderPosManager preOrdPosMgr = new PreOrderPosManager();

							if(new PreOrderManager().getPreOrderByCode(preOrder.getOrderCode())==null)
								preOrdMgr.saveOrUpdatePreOrder(preOrder);
						// ���������� ������
							for(WmPreOrderPos preOrderPos0 : preOrderPosList){
								if(new PreOrderManager().getPreOrderById(preOrderPos0.getOrderId())!= null)
									if(preOrdPosMgr.getPreOrderPosByArticleQState(preOrder.getOrderId(), preOrderPos0.getArticleId(), preOrderPos0.getQualityStateId())==null)
										preOrdPosMgr.addOrUpdatePreOrderPos(preOrderPos0);
							}

						}
						*/

						//////////////////
					}
				}

			} catch (ParserConfigurationException | SAXException | IOException e) {
				e.printStackTrace();
			}
		}

		System.out.println(":::::::::::::: End of chapter.");


	}

	public void closeConnection(){
		preOrdMgr.closeConnection();
	}

	private String getXML(ServiceMessageType messageType) throws RemoteException {

		String result;

		switch (messageType) {
/*
		case SHIPMENT:
			result = proxy.getShipments("WMS");
			break;
		case ADVICE:
			result = proxy.getAdviceInvoices("WMS");
			break;
		case MOVEMENT:
			result = proxy.getMovements("WMS");
			break;*/
		case ARTICLE:
			result = proxy.getSkladskoySostav("WMS", true, null);
			break;
		default:
			result = "";
			break;
		}

		return result;
	}



}
