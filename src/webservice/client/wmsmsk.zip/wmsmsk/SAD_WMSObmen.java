/**
 * SAD_WMSObmen.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package webservice.client.wmsmsk;

public interface SAD_WMSObmen extends javax.xml.rpc.Service {
    public java.lang.String getSAD_WMSObmenSoapAddress();

    public webservice.client.wmsmsk.SAD_WMSObmenPortType getSAD_WMSObmenSoap() throws javax.xml.rpc.ServiceException;

    public webservice.client.wmsmsk.SAD_WMSObmenPortType getSAD_WMSObmenSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
