package webservice.client.wmsmsk;

public class Loader {

	public static void main(String[] args) {
		WSReciveController ctrl = new WSReciveController();
		ctrl.closeConnection();
	}



}
